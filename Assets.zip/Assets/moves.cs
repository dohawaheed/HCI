using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using System.Threading;

public class moves : MonoBehaviour
{
    public Rigidbody2D myrigid;
    Thread mThread;
    public string connectionIP = "10.10.173.35";
    public int connectionPort = 25467;
    IPAddress localAdd;
    TcpListener listener;
    TcpClient client;
    Vector3 rotationAngles = Vector3.zero; // Store the rotation data
    bool running;
    // Start is called before the first frame update
    void Start()
    {
        ThreadStart ts = new ThreadStart(GetInfo);
        mThread = new Thread(ts);
        mThread.Start();
    }

    // Update is called once per frame
    void Update()
    {
        // Update the position based on the Y-value
        transform.position = new Vector3(-10, rotationAngles.y, 0);

        // Update the rotation based on the received rotation data
        transform.eulerAngles = rotationAngles;
    }
    void GetInfo()
    {
        localAdd = IPAddress.Parse(connectionIP);
        listener = new TcpListener(IPAddress.Any, connectionPort);
        listener.Start();
        client = listener.AcceptTcpClient();
        running = true;

        while (running)
        {
            SendAndReceiveData();
        }

        listener.Stop();
    }

    void SendAndReceiveData()
    {
        NetworkStream nwStream = client.GetStream();
        byte[] buffer = new byte[client.ReceiveBufferSize];
        int bytesRead = nwStream.Read(buffer, 0, client.ReceiveBufferSize);
        string dataReceived = Encoding.UTF8.GetString(buffer, 0, bytesRead);

        if (dataReceived != null)
        {
            rotationAngles = StringToVector3(dataReceived);
        }
    }

    Vector3 StringToVector3(string sVector)
    {
        string[] sArray = sVector.Split(',');
        float x = float.Parse(sArray[0]);
        float y = float.Parse(sArray[1]);
        float z = float.Parse(sArray[2]);
        return new Vector3(x, y, z);
    }
}

